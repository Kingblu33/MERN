import './App.css';
import 'bootstrap/dist/css/bootstrap.min.css';
import BoxGen from './components/BoxGen';

function App() {

  return (
    <div className="container">
      <BoxGen />
    </div >
  );
}

export default App;
