import React from 'react';


const TabContent = (props) => {
    const { tab, setTab } = props;

    const onClickHandler = (index) => {
        setTab({
            ...tab,
            selectedTab: index,
        })

    }

    return (
        <div>
            <div className="d-flex justify-content-evenly ">
                {
                    tab.content.map((tab, index) => (
                        <button style={{ width: "600px", height: "50px", margin: "5px" }} className={"btn btn-secondary ml-2"} onClick={() => onClickHandler(index)}>
                            Tab {index + 1}
                        </button>
                    ))
                }
            </div>
            <div style={{ width: "1300px", height: "100px", border: "2px solid black" }}>
                <h4> {props.tab.content[props.tab.selectedTab]}</h4>
            </div>
        </div>

    )

}

export default TabContent;