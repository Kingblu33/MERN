import { useState } from 'react';
import 'bootstrap/dist/css/bootstrap.css';
import TabContent from './components/TabContent';

import './App.css';

function App() {
  const [tabs, setTab] = useState({
    content: ["Tab 1 content", "Tab 2 Content", "Tab 3 Content"],
    selectedTab: 0,
  })


  return (
    <div className="container mt-5">
      <h1 className='text-center'>Tabs</h1>
      <TabContent tab={tabs} setTab={setTab} />
    </div>
  );
}

export default App;

