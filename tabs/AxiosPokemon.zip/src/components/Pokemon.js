import { useEffect, useState } from 'react';
import axios from 'axios';

const Pokemon = (props) => {

    const [poke, setPoke] = useState([]);

    const fetchPokemon = () => {

        axios.get('https://pokeapi.co/api/v2/pokemon?limit=807')
            .then(response => {
                let results = response.data.results.map(p => p.name)
                setPoke(results)
            })
            .catch(err => console.log(err))
    }


    return (
        <div className="container">
            <h1>Fetch Pokemons</h1>
            <div className="button-row">
                <button onClick={() => fetchPokemon()} >Get Pokemons!</button>
            </div>
            <ul>
                {
                    poke.map((item, i) => {
                        return <li key={i}>{i}. {item} </li>
                    })
                }
            </ul>


        </div>
    );


}

export default Pokemon;