import React, { useState, useEffect } from 'react'

const Pokemon = (props) => {
    const [poke, setPoke] = useState([]);

    const getPokemon = () => {
        fetch(' https://pokeapi.co/api/v2/pokemon?limit=807')
            .then(response => response.json())
            .then(response => setPoke(response.results))
    };

    return (
        <div>
            <button className='btn btn-success' onClick={getPokemon}>Generate Pokemons</button>
            <div>
                {
                    poke.map((poke, index) => {
                        return <ul><li key={index}>{index}.{poke.name}</li></ul>
                    })
                }

            </div>

        </div>
    );
}
export default Pokemon;